package com.example

import com.example.util.OvertimeCalculator
import org.junit.Assert.*
import org.junit.Test
import java.util.Calendar
import java.util.Date

class ExampleUnitTest {

  @Test
  fun testStandardOfficeDuty_8AM_to_5PM() {
    // 08:00 AM to 05:00 PM (17:00)
    // 9 hours total span - 1 hour lunch = 8 hours duty (480 mins)
    // Standard End = 08:00 AM + 9 hours = 05:00 PM
    // Overtime = 0 full hours -> "00:00"
    val result = OvertimeCalculator.calculateDutyAndOvertime(
      entryHour = 8, entryMinute = 0,
      exitHour = 17, exitMinute = 0
    )
    assertEquals(8 * 60, result.totalDutyMinutes)
    assertEquals("08:00", result.totalDutyFormatted)
    assertEquals(0, result.overtimeMinutes)
    assertEquals("00:00", result.overtimeFormatted)
    assertEquals("05:00 PM", result.standardEndFormatted)
  }

  @Test
  fun testPromptExample_StandardEnd6PM_Exit655PM_Overtime0000() {
    // User Prompt Example 1:
    // Standard End = 06:00 PM (Entry = 09:00 AM), Punch Out = 06:55 PM
    // Overtime must NEVER contain minutes; strictly increments in full hours only
    // 55 minutes after shift end -> full hours = 0 -> "00:00"
    val result = OvertimeCalculator.calculateDutyAndOvertime(
      entryHour = 9, entryMinute = 0,
      exitHour = 18, exitMinute = 55
    )
    assertEquals("06:00 PM", result.standardEndFormatted)
    // Total span: 9h 55m = 595 mins. Lunch deduction: 60 mins. Total duty = 535 mins = 8h 55m -> "08:55"
    assertEquals("08:55", result.totalDutyFormatted)
    assertEquals(0, result.overtimeMinutes)
    assertEquals("00:00", result.overtimeFormatted)
  }

  @Test
  fun testPromptExample_StandardEnd6PM_Exit715PM_Overtime0100() {
    // User Prompt Example 2:
    // Standard End = 06:00 PM (Entry = 09:00 AM), Punch Out = 07:15 PM (19:15)
    // 1h 15m extra -> full hours = 1 -> "01:00"
    val result = OvertimeCalculator.calculateDutyAndOvertime(
      entryHour = 9, entryMinute = 0,
      exitHour = 19, exitMinute = 15
    )
    assertEquals("06:00 PM", result.standardEndFormatted)
    // Total span: 10h 15m = 615 mins - 60 mins lunch = 555 mins = 9h 15m -> "09:15"
    assertEquals("09:15", result.totalDutyFormatted)
    assertEquals(60, result.overtimeMinutes)
    assertEquals("01:00", result.overtimeFormatted)
  }

  @Test
  fun testPromptExample_StandardEnd5PM_Exit745PM_Overtime0200() {
    // User Prompt Example 3:
    // Standard End = 05:00 PM (Entry = 08:00 AM), Punch Out = 07:45 PM (19:45)
    // 2h 45m extra -> full hours = 2 -> "02:00"
    val result = OvertimeCalculator.calculateDutyAndOvertime(
      entryHour = 8, entryMinute = 0,
      exitHour = 19, exitMinute = 45
    )
    assertEquals("05:00 PM", result.standardEndFormatted)
    // Total span: 11h 45m = 705 mins - 60 mins lunch = 645 mins = 10h 45m -> "10:45"
    assertEquals("10:45", result.totalDutyFormatted)
    assertEquals(120, result.overtimeMinutes)
    assertEquals("02:00", result.overtimeFormatted)
  }

  @Test
  fun testLunchDeduction_DuringLunchHour_Exit130PM() {
    // Entry = 08:00 AM, Exit = 01:30 PM (13:30)
    // Punch Out is between 01:00 PM and 02:00 PM:
    // Deduct exact difference (01:30 PM - 01:00 PM = 30 minutes)
    // Total span = 5h 30m = 330 mins. Lunch = 30 mins. Total Duty = 300 mins = 05:00
    val result = OvertimeCalculator.calculateDutyAndOvertime(
      entryHour = 8, entryMinute = 0,
      exitHour = 13, exitMinute = 30
    )
    assertEquals(30, result.lunchDeductedMinutes)
    assertEquals(300, result.totalDutyMinutes)
    assertEquals("05:00", result.totalDutyFormatted)
    assertEquals("00:00", result.overtimeFormatted)
  }

  @Test
  fun testDateAlignment_Avoid0msDuration() {
    // Verifies that aligning entry time with punch out date gives correct duration
    // even across different hour/minute values
    val now = Date()
    val cal = Calendar.getInstance().apply {
      time = now
      set(Calendar.HOUR_OF_DAY, 18) // 06:00 PM
      set(Calendar.MINUTE, 0)
      set(Calendar.SECOND, 0)
      set(Calendar.MILLISECOND, 0)
    }

    val result = OvertimeCalculator.calculateDutyAndOvertime(
      entryHour = 8, entryMinute = 0,
      punchOutDate = cal.time
    )

    // Entry 08:00 AM to 06:00 PM = 10h span - 1h lunch = 9h duty (540 min)
    // Standard End = 05:00 PM. Exit = 06:00 PM -> 1h overtime = "01:00"
    assertEquals(540, result.totalDutyMinutes)
    assertEquals("09:00", result.totalDutyFormatted)
    assertEquals("01:00", result.overtimeFormatted)
  }

  @Test
  fun testParseEntryTimeString() {
    val parsed8AM = OvertimeCalculator.parseEntryTimeString("08:00 AM")
    assertEquals(8, parsed8AM.first)
    assertEquals(0, parsed8AM.second)

    val parsed930AM = OvertimeCalculator.parseEntryTimeString("09:30 AM")
    assertEquals(9, parsed930AM.first)
    assertEquals(30, parsed930AM.second)

    val fallback = OvertimeCalculator.parseEntryTimeString("invalid")
    assertEquals(8, fallback.first)
    assertEquals(0, fallback.second)
  }
}
