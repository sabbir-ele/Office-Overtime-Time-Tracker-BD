package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainViewModel
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NavyPrimary

enum class AppNavDestination(
    val title: String,
    val icon: ImageVector,
    val tag: String
) {
    HOME("Home", Icons.Default.Timer, "nav_item_home"),
    HISTORY("History", Icons.Default.History, "nav_item_history"),
    SETTINGS("Settings", Icons.Default.Settings, "nav_item_settings")
}

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                OvertimeTrackerApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun OvertimeTrackerApp(viewModel: MainViewModel) {
    var currentScreen by remember { mutableStateOf(AppNavDestination.HOME) }

    // Intercept back press when on secondary screens to return to Home
    if (currentScreen != AppNavDestination.HOME) {
        BackHandler {
            currentScreen = AppNavDestination.HOME
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = com.example.ui.theme.BentoCanvas,
        bottomBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(com.example.ui.theme.BentoSurfaceCard)
            ) {
                androidx.compose.material3.HorizontalDivider(
                    thickness = 1.dp,
                    color = com.example.ui.theme.BentoBorder
                )
                NavigationBar(
                    containerColor = com.example.ui.theme.BentoSurfaceCard,
                    tonalElevation = 0.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    AppNavDestination.entries.forEach { destination ->
                        val isSelected = currentScreen == destination
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { currentScreen = destination },
                            icon = {
                                Icon(
                                    imageVector = destination.icon,
                                    contentDescription = destination.title
                                )
                            },
                            label = {
                                Text(
                                    text = destination.title,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = com.example.ui.theme.BentoPrimaryPurple,
                                selectedTextColor = com.example.ui.theme.BentoOnSurface,
                                unselectedIconColor = com.example.ui.theme.BentoOnSurfaceVariant,
                                unselectedTextColor = com.example.ui.theme.BentoOnSurfaceVariant,
                                indicatorColor = com.example.ui.theme.BentoActivePill
                            ),
                            modifier = Modifier.testTag(destination.tag)
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        AnimatedContent(
            targetState = currentScreen,
            transitionSpec = { fadeIn() togetherWith fadeOut() },
            modifier = Modifier.padding(innerPadding),
            label = "ScreenTransition"
        ) { targetScreen ->
            when (targetScreen) {
                AppNavDestination.HOME -> {
                    HomeScreen(
                        viewModel = viewModel,
                        onNavigateToHistory = { currentScreen = AppNavDestination.HISTORY },
                        onNavigateToSettings = { currentScreen = AppNavDestination.SETTINGS }
                    )
                }

                AppNavDestination.HISTORY -> {
                    HistoryScreen(
                        viewModel = viewModel,
                        onNavigateBack = { currentScreen = AppNavDestination.HOME }
                    )
                }

                AppNavDestination.SETTINGS -> {
                    SettingsScreen(
                        viewModel = viewModel,
                        onNavigateBack = { currentScreen = AppNavDestination.HOME }
                    )
                }
            }
        }
    }
}

