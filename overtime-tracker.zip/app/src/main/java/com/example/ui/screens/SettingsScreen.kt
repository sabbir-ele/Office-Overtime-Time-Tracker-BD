package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Update
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.TimePickerDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.MainViewModel
import com.example.ui.components.DeveloperInfoBottomSheet
import com.example.ui.components.DeveloperProfileAvatar
import com.example.ui.components.launchUrlSafely
import com.example.ui.theme.BentoActivePill
import com.example.ui.theme.BentoBorder
import com.example.ui.theme.BentoCanvas
import com.example.ui.theme.BentoOnSurface
import com.example.ui.theme.BentoOnSurfaceVariant
import com.example.ui.theme.BentoOvertimeBg
import com.example.ui.theme.BentoOvertimeBorder
import com.example.ui.theme.BentoOvertimeText
import com.example.ui.theme.BentoPrimaryPurple
import com.example.ui.theme.BentoPrimaryPurpleDark
import com.example.ui.theme.BentoSurfaceCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val officeEntryTime by viewModel.officeEntryTime.collectAsStateWithLifecycle()
    val officeEntryTimeString by viewModel.officeEntryTimeString.collectAsStateWithLifecycle()
    val standardShiftEndString by viewModel.standardShiftEndString.collectAsStateWithLifecycle()
    val userMessage by viewModel.userMessage.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    var showTimePickerDialog by remember { mutableStateOf(false) }
    var showDeveloperInfo by remember { mutableStateOf(false) }
    val context = LocalContext.current

    LaunchedEffect(userMessage) {
        userMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearUserMessage()
        }
    }

    if (showDeveloperInfo) {
        DeveloperInfoBottomSheet(
            onDismiss = { showDeveloperInfo = false }
        )
    }

    if (showTimePickerDialog) {
        val timePickerState = rememberTimePickerState(
            initialHour = officeEntryTime.first,
            initialMinute = officeEntryTime.second,
            is24Hour = false
        )

        AlertDialog(
            onDismissRequest = { showTimePickerDialog = false },
            title = {
                Text(
                    text = "Pick Office Entry Time",
                    fontWeight = FontWeight.Bold,
                    color = BentoOnSurface
                )
            },
            text = {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    TimePicker(
                        state = timePickerState,
                        colors = TimePickerDefaults.colors(
                            clockDialColor = BentoSurfaceCard,
                            selectorColor = BentoPrimaryPurple,
                            containerColor = Color.White
                        ),
                        modifier = Modifier.testTag("office_entry_time_picker")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.updateOfficeEntryTime(timePickerState.hour, timePickerState.minute)
                        showTimePickerDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BentoPrimaryPurple),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.testTag("save_time_picker_button")
                ) {
                    Text("Save Time", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showTimePickerDialog = false }) {
                    Text("Cancel", color = BentoOnSurfaceVariant)
                }
            }
        )
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(BentoCanvas),
        containerColor = BentoCanvas,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Settings",
                        fontWeight = FontWeight.SemiBold,
                        color = BentoOnSurface,
                        letterSpacing = (-0.5).sp
                    )
                },
                navigationIcon = {
                    Surface(
                        shape = CircleShape,
                        color = BentoSurfaceCard,
                        modifier = Modifier
                            .padding(start = 12.dp)
                            .size(40.dp)
                            .testTag("settings_back_button")
                    ) {
                        IconButton(onClick = onNavigateBack) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = BentoOnSurface,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                },
                actions = {
                    Surface(
                        shape = CircleShape,
                        color = BentoSurfaceCard,
                        modifier = Modifier
                            .padding(end = 12.dp)
                            .size(40.dp)
                            .clickable { showDeveloperInfo = true }
                            .testTag("settings_developer_info_button")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = "Developer Profile",
                                tint = BentoPrimaryPurple,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = BentoCanvas
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Office Entry Time Bento Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = BentoSurfaceCard),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = BentoActivePill,
                            modifier = Modifier.size(42.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.AccessTime,
                                    contentDescription = null,
                                    tint = BentoPrimaryPurple,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }

                        Column {
                            Text(
                                text = "Default Office Entry Time",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = BentoOnSurface
                            )
                            Text(
                                text = "Configurable daily start time",
                                fontSize = 13.sp,
                                color = BentoOnSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = Color.White,
                        border = androidx.compose.foundation.BorderStroke(1.dp, BentoBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(18.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Current Entry Time",
                                    fontSize = 12.sp,
                                    color = BentoOnSurfaceVariant
                                )
                                Text(
                                    text = officeEntryTimeString,
                                    fontSize = 28.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = BentoPrimaryPurple,
                                    letterSpacing = (-0.5).sp
                                )
                            }

                            Button(
                                onClick = { showTimePickerDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = BentoPrimaryPurple),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.testTag("change_entry_time_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Schedule,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Change", fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedButton(
                        onClick = { viewModel.resetOfficeEntryTimeToDefault() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("reset_entry_time_button"),
                        shape = RoundedCornerShape(16.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, BentoBorder)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = null,
                            tint = BentoOnSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Reset to Default (08:00 AM)", color = BentoOnSurface)
                    }
                }
            }

            // 2. Calculation Rules & Policy Bento Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = BentoSurfaceCard),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = BentoOvertimeBg,
                            border = androidx.compose.foundation.BorderStroke(1.dp, BentoOvertimeBorder),
                            modifier = Modifier.size(42.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Info,
                                    contentDescription = null,
                                    tint = BentoOvertimeText,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }

                        Column {
                            Text(
                                text = "Duty & Overtime Rules",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = BentoOnSurface
                            )
                            Text(
                                text = "Standard office duty logic",
                                fontSize = 13.sp,
                                color = BentoOnSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    RuleRow(
                        icon = Icons.Default.Work,
                        title = "Office Duty Schedule (9h Mandatory)",
                        description = "$officeEntryTimeString to $standardShiftEndString (Standard End = Entry + 9 hours)"
                    )

                    HorizontalDivider(
                        modifier = Modifier.padding(vertical = 10.dp),
                        color = BentoBorder.copy(alpha = 0.5f)
                    )

                    RuleRow(
                        icon = Icons.Default.Restaurant,
                        title = "Lunch Break (1h)",
                        description = "01:00 PM to 02:00 PM (1h deducted; exact difference if punched out during lunch)"
                    )

                    HorizontalDivider(
                        modifier = Modifier.padding(vertical = 10.dp),
                        color = BentoBorder.copy(alpha = 0.5f)
                    )

                    RuleRow(
                        icon = Icons.Default.Timer,
                        title = "Total Duty Calculation",
                        description = "(Punch Out - Punch In) - Lunch Duration. Formatted as hh:mm"
                    )

                    HorizontalDivider(
                        modifier = Modifier.padding(vertical = 10.dp),
                        color = BentoBorder.copy(alpha = 0.5f)
                    )

                    RuleRow(
                        icon = Icons.Default.Schedule,
                        title = "Strict Full-Hour Overtime",
                        description = "Starts after $standardShiftEndString. Full hours only (00:00, 01:00, 02:00); minutes under 60 do not count"
                    )
                }
            }

            // 3. Security & Restart Protection Info Bento Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = BentoActivePill),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = null,
                            tint = BentoPrimaryPurple,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "Date Locking & Restart Protection",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = BentoPrimaryPurple
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Once you click 'Punch Out' on any day, today's record is saved in your local Room database and locked. Even after closing or restarting the app, the button remains locked with 'Already Punched' status.",
                        fontSize = 12.sp,
                        color = BentoOnSurfaceVariant
                    )
                }
            }

            // 4. Developer Profile & Interactive Action Links Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = BentoSurfaceCard),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        DeveloperProfileAvatar(
                            size = 56.dp,
                            modifier = Modifier.testTag("settings_profile_avatar")
                        )

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Md. Sabbir Rahman",
                                fontWeight = FontWeight.Bold,
                                fontSize = 17.sp,
                                color = BentoOnSurface
                            )
                            Text(
                                text = "Sub-Assistant Engineer (Electrical & Electronics)",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = BentoPrimaryPurple
                            )
                            Text(
                                text = "B.Sc. in EEE, City University",
                                fontSize = 11.sp,
                                color = BentoOnSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Professional utility app for tracking duty shifts, automated lunch deductions, and strict full-hour overtime calculation.",
                        fontSize = 12.sp,
                        lineHeight = 17.sp,
                        color = BentoOnSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    HorizontalDivider(
                        thickness = 1.dp,
                        color = BentoBorder.copy(alpha = 0.6f)
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "Interactive Profiles & Repository",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = BentoOnSurface
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Row 1: WhatsApp & LinkedIn
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        QuickActionChip(
                            label = "WhatsApp Chat",
                            subtitle = "+880 1798 998006",
                            icon = Icons.Default.Send,
                            color = Color(0xFF25D366),
                            modifier = Modifier.weight(1f),
                            testTag = "settings_chip_whatsapp",
                            onClick = { launchUrlSafely(context, "https://wa.me/8801798998006") }
                        )
                        QuickActionChip(
                            label = "LinkedIn Profile",
                            subtitle = "md-sabbir-rahman",
                            icon = Icons.Default.AccountCircle,
                            color = Color(0xFF0A66C2),
                            modifier = Modifier.weight(1f),
                            testTag = "settings_chip_linkedin",
                            onClick = { launchUrlSafely(context, "https://www.linkedin.com/in/md-sabbir-rahman-646071269/") }
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Row 2: GitHub & Project Updates
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        QuickActionChip(
                            label = "GitHub Profile",
                            subtitle = "@sabbir-ele",
                            icon = Icons.Default.Code,
                            color = BentoOnSurface,
                            modifier = Modifier.weight(1f),
                            testTag = "settings_chip_github",
                            onClick = { launchUrlSafely(context, "https://github.com/sabbir-ele/") }
                        )
                        QuickActionChip(
                            label = "Project Updates",
                            subtitle = "Releases & Roadmap",
                            icon = Icons.Default.Update,
                            color = BentoPrimaryPurple,
                            modifier = Modifier.weight(1f),
                            testTag = "settings_chip_updates",
                            onClick = { launchUrlSafely(context, "https://github.com/sabbir-ele/Office-Overtime-Time-Tracker-BD/projects") }
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedButton(
                        onClick = { showDeveloperInfo = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("open_developer_sheet_button"),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, BentoBorder)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = BentoPrimaryPurple,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "View Developer Details & Sheet",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = BentoPrimaryPurple
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun QuickActionChip(
    label: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = ""
) {
    Card(
        modifier = modifier
            .clickable { onClick() }
            .testTag(testTag),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = BentoCanvas),
        border = BorderStroke(1.dp, BentoBorder.copy(alpha = 0.7f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = Color.White,
                    modifier = Modifier.size(28.dp),
                    border = BorderStroke(1.dp, BentoBorder.copy(alpha = 0.4f))
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = color,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
                Text(
                    text = label,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = BentoOnSurface,
                    maxLines = 1
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = subtitle,
                fontSize = 10.sp,
                color = BentoOnSurfaceVariant,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun RuleRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    description: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.Top
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = BentoPrimaryPurple,
            modifier = Modifier
                .padding(top = 2.dp)
                .size(18.dp)
        )
        Column {
            Text(
                text = title,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = BentoOnSurface
            )
            Text(
                text = description,
                fontSize = 12.sp,
                color = BentoOnSurfaceVariant
            )
        }
    }
}
