package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Bento Grid Theme Colors
val BentoCanvas = Color(0xFFFEF7FF)
val BentoOnSurface = Color(0xFF1D1B20)
val BentoOnSurfaceVariant = Color(0xFF49454F)
val BentoSurfaceCard = Color(0xFFF3EDF7)
val BentoActivePill = Color(0xFFE8DEF8)
val BentoPrimaryPurple = Color(0xFF6750A4)
val BentoPrimaryPurpleDark = Color(0xFF4F378B)
val BentoBorder = Color(0xFFCAC4D0)

// Bento Grid Tile Colors
val BentoEntryBg = Color(0xFFDDE1FF)
val BentoEntryText = Color(0xFF001453)

val BentoLunchBg = Color(0xFFE1F5FE)
val BentoLunchText = Color(0xFF01579B)

val BentoDutyBg = Color(0xFFF1F8E9)
val BentoDutyText = Color(0xFF33691E)

val BentoOvertimeBg = Color(0xFFFFF3E0)
val BentoOvertimeBorder = Color(0xFFFF9800)
val BentoOvertimeText = Color(0xFFE65100)

// Primary Colors - aliased for compatibility
val NavyPrimary = BentoPrimaryPurple
val NavyPrimaryLight = BentoPrimaryPurple
val NavyPrimaryDark = BentoPrimaryPurpleDark
val NavyContainer = BentoActivePill
val OnNavyContainer = BentoPrimaryPurple

// Secondary Colors
val SlateSecondary = BentoOnSurfaceVariant
val SlateSecondaryContainer = BentoSurfaceCard
val OnSlateSecondary = Color.White

// Tertiary Colors - Overtime Amber / Warm Gold
val AmberTertiary = BentoOvertimeText
val AmberContainer = BentoOvertimeBg
val OnAmberContainer = BentoOvertimeText

// Status & Functional Colors
val PunchSuccess = Color(0xFF2E7D32)
val PunchSuccessContainer = Color(0xFFE8F5E9)
val PunchLocked = Color(0xFF9E9E9E)
val OvertimeHighlight = BentoOvertimeText

// Surface & Background
val LightBackground = BentoCanvas
val LightSurface = Color.White
val LightSurfaceVariant = BentoSurfaceCard
val LightOutline = BentoBorder
val LightOutlineVariant = BentoBorder

// Dark Theme Variants
val DarkPrimary = Color(0xFFD0BCFF)
val DarkBackground = Color(0xFF141218)
val DarkSurface = Color(0xFF1D1B20)
val DarkSurfaceVariant = Color(0xFF49454F)
val DarkOutline = Color(0xFF938F99)


