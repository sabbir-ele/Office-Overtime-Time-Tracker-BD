package com.example.ui.components

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Update
import androidx.compose.material3.BottomSheetDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.BentoActivePill
import com.example.ui.theme.BentoBorder
import com.example.ui.theme.BentoCanvas
import com.example.ui.theme.BentoOnSurface
import com.example.ui.theme.BentoOnSurfaceVariant
import com.example.ui.theme.BentoPrimaryPurple
import com.example.ui.theme.BentoSurfaceCard

private const val URL_WHATSAPP = "https://wa.me/8801798998006"
private const val URL_LINKEDIN = "https://www.linkedin.com/in/md-sabbir-rahman-646071269/"
private const val URL_GITHUB = "https://github.com/sabbir-ele/"
private const val URL_PROJECT_UPDATES = "https://github.com/sabbir-ele/Office-Overtime-Time-Tracker-BD/projects"

/**
 * Safely launches a web or application intent catching ActivityNotFoundException
 */
fun launchUrlSafely(context: Context, url: String) {
    try {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(context, "No web browser application found to open link", Toast.LENGTH_SHORT).show()
    } catch (e: Exception) {
        Toast.makeText(context, "Unable to open link", Toast.LENGTH_SHORT).show()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeveloperInfoBottomSheet(
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val context = LocalContext.current

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = BentoCanvas,
        dragHandle = { BottomSheetDefaults.DragHandle() },
        modifier = modifier.testTag("developer_info_bottom_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState())
                .padding(bottom = 36.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Circular Developer Profile Image (88dp with 2dp primary color border and fallback)
            DeveloperProfileAvatar(
                size = 88.dp,
                modifier = Modifier.testTag("bottom_sheet_profile_pic")
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Developer Name
            Text(
                text = "Md. Sabbir Rahman",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = BentoOnSurface,
                letterSpacing = (-0.3).sp
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Profession Chip
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = BentoActivePill,
                border = BorderStroke(1.dp, BentoBorder)
            ) {
                Text(
                    text = "Sub-Assistant Engineer (Electrical & Electronics)",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = BentoPrimaryPurple,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                    textAlign = TextAlign.Center
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Academic Background
            Text(
                text = "B.Sc. in EEE, City University",
                fontSize = 13.sp,
                color = BentoOnSurfaceVariant,
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Description Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = BentoSurfaceCard),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = BentoPrimaryPurple,
                        modifier = Modifier
                            .padding(top = 2.dp)
                            .size(18.dp)
                    )
                    Text(
                        text = "Professional utility app for tracking duty shifts, automated lunch deductions, and strict full-hour overtime calculation.",
                        fontSize = 13.sp,
                        lineHeight = 18.sp,
                        color = BentoOnSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Interactive Action Links Section Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Developer Profiles & Repository",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = BentoOnSurface
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action 1: WhatsApp
            DeveloperActionCard(
                title = "WhatsApp Chat",
                subtitle = "+880 1798 998006 (Direct Contact)",
                icon = Icons.Default.Send,
                iconTint = Color(0xFF25D366),
                testTag = "action_whatsapp",
                onClick = { launchUrlSafely(context, URL_WHATSAPP) }
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Action 2: LinkedIn
            DeveloperActionCard(
                title = "LinkedIn Profile",
                subtitle = "md-sabbir-rahman-646071269",
                icon = Icons.Default.AccountCircle,
                iconTint = Color(0xFF0A66C2),
                testTag = "action_linkedin",
                onClick = { launchUrlSafely(context, URL_LINKEDIN) }
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Action 3: GitHub Profile
            DeveloperActionCard(
                title = "GitHub Profile",
                subtitle = "github.com/sabbir-ele",
                icon = Icons.Default.Code,
                iconTint = BentoOnSurface,
                testTag = "action_github",
                onClick = { launchUrlSafely(context, URL_GITHUB) }
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Action 4: Project Updates & Releases
            DeveloperActionCard(
                title = "Project Updates & Roadmap",
                subtitle = "Releases, Issues & Project Board",
                icon = Icons.Default.Update,
                iconTint = BentoPrimaryPurple,
                testTag = "action_project_updates",
                onClick = { launchUrlSafely(context, URL_PROJECT_UPDATES) }
            )

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedButton(
                onClick = onDismiss,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, BentoBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("dismiss_developer_sheet_button")
            ) {
                Text("Close", color = BentoOnSurfaceVariant, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun DeveloperActionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    iconTint: Color,
    testTag: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag(testTag),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = BentoSurfaceCard),
        border = BorderStroke(1.dp, BentoBorder.copy(alpha = 0.6f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                Surface(
                    shape = CircleShape,
                    color = Color.White,
                    modifier = Modifier.size(40.dp),
                    border = BorderStroke(1.dp, BentoBorder.copy(alpha = 0.4f))
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = iconTint,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Column {
                    Text(
                        text = title,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = BentoOnSurface
                    )
                    Text(
                        text = subtitle,
                        fontSize = 12.sp,
                        color = BentoOnSurfaceVariant
                    )
                }
            }

            Icon(
                imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                contentDescription = "Open link",
                tint = BentoOnSurfaceVariant.copy(alpha = 0.6f),
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

/**
 * Circular profile avatar displaying R.drawable.profile_pic with 88dp diameter,
 * Center Crop, and 2dp border matching BentoPrimaryPurple.
 * Gracefully falls back to a developer/person vector icon if not found or failing to load.
 */
@Composable
fun DeveloperProfileAvatar(
    modifier: Modifier = Modifier,
    size: Dp = 88.dp
) {
    val context = LocalContext.current
    val hasDrawable = remember(context) {
        try {
            val id = R.drawable.profile_pic
            id != 0 && context.resources.getResourceName(id) != null
        } catch (e: Throwable) {
            false
        }
    }

    Surface(
        shape = CircleShape,
        color = BentoActivePill,
        border = BorderStroke(2.dp, BentoPrimaryPurple),
        shadowElevation = 3.dp,
        modifier = modifier
            .size(size)
            .testTag("developer_profile_avatar")
    ) {
        if (hasDrawable) {
            Image(
                painter = painterResource(id = R.drawable.profile_pic),
                contentDescription = "Md. Sabbir Rahman Profile Picture",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .clip(CircleShape)
            )
        } else {
            // Graceful fallback to developer/person vector icon instead of plain text
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.fillMaxSize()
            ) {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = "Developer Profile",
                    tint = BentoPrimaryPurple,
                    modifier = Modifier.size(size * 0.55f)
                )
            }
        }
    }
}
