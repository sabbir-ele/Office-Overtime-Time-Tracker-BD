package com.example.ui.screens

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.MainViewModel
import com.example.ui.components.DeveloperInfoBottomSheet
import com.example.ui.theme.BentoActivePill
import com.example.ui.theme.BentoBorder
import com.example.ui.theme.BentoCanvas
import com.example.ui.theme.BentoDutyBg
import com.example.ui.theme.BentoDutyText
import com.example.ui.theme.BentoEntryBg
import com.example.ui.theme.BentoEntryText
import com.example.ui.theme.BentoLunchBg
import com.example.ui.theme.BentoLunchText
import com.example.ui.theme.BentoOnSurface
import com.example.ui.theme.BentoOnSurfaceVariant
import com.example.ui.theme.BentoOvertimeBg
import com.example.ui.theme.BentoOvertimeBorder
import com.example.ui.theme.BentoOvertimeText
import com.example.ui.theme.BentoPrimaryPurple
import com.example.ui.theme.BentoPrimaryPurpleDark
import com.example.ui.theme.BentoSurfaceCard
import com.example.ui.theme.PunchLocked

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    onNavigateToHistory: () -> Unit,
    onNavigateToSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val liveClock by viewModel.liveClock.collectAsStateWithLifecycle()
    val displayDate by viewModel.displayDate.collectAsStateWithLifecycle()
    val dayOfWeek by viewModel.dayOfWeek.collectAsStateWithLifecycle()
    val officeEntryTimeString by viewModel.officeEntryTimeString.collectAsStateWithLifecycle()
    val standardShiftEndString by viewModel.standardShiftEndString.collectAsStateWithLifecycle()
    val isPunchedToday by viewModel.isPunchedToday.collectAsStateWithLifecycle()
    val todayRecord by viewModel.todayRecord.collectAsStateWithLifecycle()
    val liveTotalDuty by viewModel.liveTotalDuty.collectAsStateWithLifecycle()
    val liveOvertime by viewModel.liveOvertime.collectAsStateWithLifecycle()
    val recentRecords by viewModel.records.collectAsStateWithLifecycle()
    val userMessage by viewModel.userMessage.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    var showPunchConfirmDialog by remember { mutableStateOf(false) }
    var showDeveloperInfo by remember { mutableStateOf(false) }

    // Pulsing animation for active shift badge
    val infiniteTransition = rememberInfiniteTransition(label = "Pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(800),
            repeatMode = RepeatMode.Reverse
        ),
        label = "PulseAlpha"
    )

    LaunchedEffect(userMessage) {
        userMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearUserMessage()
        }
    }

    if (showPunchConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showPunchConfirmDialog = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.ExitToApp,
                    contentDescription = null,
                    tint = BentoPrimaryPurple,
                    modifier = Modifier.size(32.dp)
                )
            },
            title = {
                Text(
                    text = "Punch Out for Today?",
                    fontWeight = FontWeight.Bold,
                    color = BentoOnSurface
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("$dayOfWeek, $displayDate", color = BentoOnSurfaceVariant)
                    Text("Office Entry: $officeEntryTimeString  •  Standard End: $standardShiftEndString", fontWeight = FontWeight.Medium)
                    Text("Punch Out Time: $liveClock", fontWeight = FontWeight.Bold)
                    Text(
                        text = "Total Duty: $liveTotalDuty  •  Overtime: $liveOvertime",
                        fontWeight = FontWeight.SemiBold,
                        color = BentoOvertimeText
                    )
                    Text(
                        text = "Note: Date locking & restart protection will lock the button for today.",
                        style = MaterialTheme.typography.bodySmall,
                        color = BentoOnSurfaceVariant
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showPunchConfirmDialog = false
                        viewModel.punchOut()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BentoPrimaryPurple),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.testTag("confirm_punch_out_button")
                ) {
                    Text("Confirm Punch Out", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showPunchConfirmDialog = false }) {
                    Text("Cancel", color = BentoOnSurfaceVariant)
                }
            }
        )
    }

    if (showDeveloperInfo) {
        DeveloperInfoBottomSheet(
            onDismiss = { showDeveloperInfo = false }
        )
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(BentoCanvas),
        containerColor = BentoCanvas,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            // Bento Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Overtime Tracker",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = (-0.5).sp,
                    color = BentoOnSurface
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Developer Info Nav Button
                    Surface(
                        shape = CircleShape,
                        color = BentoSurfaceCard,
                        modifier = Modifier
                            .size(44.dp)
                            .clickable { showDeveloperInfo = true }
                            .testTag("nav_developer_info_button")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = "Developer Profile & Links",
                                tint = BentoPrimaryPurple,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    // History Nav Button
                    Surface(
                        shape = CircleShape,
                        color = BentoSurfaceCard,
                        modifier = Modifier
                            .size(44.dp)
                            .clickable { onNavigateToHistory() }
                            .testTag("nav_history_icon_button")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.History,
                                contentDescription = "History",
                                tint = BentoOnSurface,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    // Settings Nav Button
                    Surface(
                        shape = CircleShape,
                        color = BentoSurfaceCard,
                        modifier = Modifier
                            .size(44.dp)
                            .clickable { onNavigateToSettings() }
                            .testTag("nav_settings_icon_button")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Settings",
                                tint = BentoOnSurface,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. Hero Bento Card: Live Real-Time Clock & Date Display
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(32.dp),
                    colors = CardDefaults.cardColors(containerColor = BentoSurfaceCard),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Uppercase Date Display
                        Text(
                            text = "$dayOfWeek, $displayDate".uppercase(),
                            style = MaterialTheme.typography.labelMedium.copy(
                                letterSpacing = 1.2.sp,
                                fontWeight = FontWeight.SemiBold
                            ),
                            color = BentoOnSurfaceVariant,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Large Digital Clock
                        Text(
                            text = liveClock,
                            fontSize = 44.sp,
                            fontWeight = FontWeight.Light,
                            letterSpacing = (-1).sp,
                            color = BentoOnSurface,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Active / Completed Status Pill
                        Surface(
                            shape = CircleShape,
                            color = BentoActivePill
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(if (isPunchedToday) PunchLocked else BentoPrimaryPurple)
                                        .then(
                                            if (!isPunchedToday) Modifier.alpha(pulseAlpha) else Modifier
                                        )
                                )
                                Text(
                                    text = if (isPunchedToday) "SHIFT COMPLETED" else "SHIFT ACTIVE",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.8.sp,
                                    color = if (isPunchedToday) BentoOnSurfaceVariant else BentoPrimaryPurple
                                )
                            }
                        }
                    }
                }
            }

            // 2. Bento 2x2 Grid (Entry Time, Lunch Break, Total Duty, Overtime)
            item {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Row 1: Entry Time & Lunch Break
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Bento Tile 1: Entry Time
                        BentoTile(
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onNavigateToSettings() },
                            containerColor = BentoEntryBg,
                            contentColor = BentoEntryText,
                            label = "Entry Time",
                            value = officeEntryTimeString,
                            subtitle = "Standard Entry (Tap to edit)",
                            icon = Icons.Default.Schedule
                        )

                        // Bento Tile 2: Lunch Break
                        BentoTile(
                            modifier = Modifier.weight(1f),
                            containerColor = BentoLunchBg,
                            contentColor = BentoLunchText,
                            label = "Lunch Break",
                            value = "-1:00",
                            subtitle = "Auto-deducted (1-2 PM)",
                            icon = Icons.Default.Restaurant
                        )
                    }

                    // Row 2: Total Duty & Overtime
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Bento Tile 3: Total Duty
                        val displayDuty = todayRecord?.totalDutyFormatted ?: liveTotalDuty
                        BentoTile(
                            modifier = Modifier.weight(1f),
                            containerColor = BentoDutyBg,
                            contentColor = BentoDutyText,
                            label = "Total Duty",
                            value = displayDuty,
                            subtitle = if (isPunchedToday) "Duty Finalized" else "Incl. lunch deduction",
                            icon = Icons.Default.Timer
                        )

                        // Bento Tile 4: Overtime (accented border)
                        val displayOvertime = todayRecord?.overtimeFormatted ?: liveOvertime
                        BentoTile(
                            modifier = Modifier.weight(1f),
                            containerColor = BentoOvertimeBg,
                            contentColor = BentoOvertimeText,
                            label = "Overtime",
                            value = displayOvertime,
                            subtitle = "After $standardShiftEndString",
                            icon = Icons.Default.CheckCircle,
                            borderColor = BentoOvertimeBorder
                        )
                    }
                }
            }

            // 3. Punch Out Action Button (Bento style, rounded 28dp, height 72dp)
            item {
                if (isPunchedToday) {
                    // Already Punched State
                    Button(
                        onClick = { /* Locked */ },
                        enabled = false,
                        shape = RoundedCornerShape(28.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(72.dp)
                            .testTag("punch_out_button"),
                        colors = ButtonDefaults.buttonColors(
                            disabledContainerColor = BentoSurfaceCard,
                            disabledContentColor = BentoOnSurfaceVariant
                        )
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "Locked",
                                modifier = Modifier.size(24.dp),
                                tint = BentoOnSurfaceVariant
                            )
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "Already Punched",
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp,
                                    color = BentoOnSurfaceVariant
                                )
                                Text(
                                    text = "Restart Protection Active: Locked until tomorrow",
                                    fontSize = 11.sp,
                                    color = BentoOnSurfaceVariant.copy(alpha = 0.7f)
                                )
                            }
                        }
                    }
                } else {
                    // Active Punch Out Now Button
                    Button(
                        onClick = { showPunchConfirmDialog = true },
                        shape = RoundedCornerShape(28.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = BentoPrimaryPurple
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(72.dp)
                            .testTag("punch_out_button"),
                        elevation = ButtonDefaults.buttonElevation(
                            defaultElevation = 4.dp,
                            pressedElevation = 1.dp
                        )
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ExitToApp,
                                contentDescription = null,
                                modifier = Modifier.size(26.dp),
                                tint = Color.White
                            )
                            Text(
                                text = "PUNCH OUT NOW",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp,
                                color = Color.White
                            )
                        }
                    }
                }
            }

            // 4. Bento Section: Recent Activity
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp, bottom = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Recent Activity",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = BentoOnSurface
                    )
                    TextButton(
                        onClick = onNavigateToHistory,
                        modifier = Modifier.testTag("view_all_history_button")
                    ) {
                        Text(
                            text = "Full History",
                            fontWeight = FontWeight.Bold,
                            color = BentoPrimaryPurple
                        )
                    }
                }
            }

            if (recentRecords.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = BentoSurfaceCard)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "No records recorded yet",
                                fontWeight = FontWeight.Medium,
                                color = BentoOnSurface
                            )
                            Text(
                                text = "Click 'PUNCH OUT NOW' above to save today's record",
                                fontSize = 13.sp,
                                color = BentoOnSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            } else {
                items(recentRecords.take(3), key = { it.id }) { record ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = BentoSurfaceCard)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "${record.displayDate} (${record.dayOfWeek})",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = BentoOnSurface
                                )
                                Text(
                                    text = "${record.punchInTime}  ➔  ${record.punchOutTime}",
                                    fontSize = 13.sp,
                                    color = BentoOnSurfaceVariant
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "Duty: ${record.totalDutyFormatted}",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 14.sp,
                                    color = BentoOnSurface
                                )
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (record.overtimeMinutes > 0) BentoOvertimeBg else BentoActivePill
                                ) {
                                    Text(
                                        text = "+OT: ${record.overtimeFormatted}",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (record.overtimeMinutes > 0) BentoOvertimeText else BentoOnSurfaceVariant,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}

/**
 * Bento Grid Individual Tile Component
 */
@Composable
private fun BentoTile(
    label: String,
    value: String,
    subtitle: String,
    containerColor: Color,
    contentColor: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier,
    borderColor: Color? = null
) {
    Card(
        modifier = modifier.height(130.dp),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        border = borderColor?.let {
            androidx.compose.foundation.BorderStroke(2.dp, it)
        },
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = label,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = contentColor
                )
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = contentColor.copy(alpha = 0.7f),
                    modifier = Modifier.size(16.dp)
                )
            }

            Column {
                Text(
                    text = value,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = contentColor,
                    letterSpacing = (-0.5).sp
                )
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = contentColor.copy(alpha = 0.75f)
                )
            }
        }
    }
}
