package com.example.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.OvertimeRecord
import com.example.data.preferences.SettingsPreferences
import com.example.data.repository.OvertimeRepository
import com.example.util.OvertimeCalculator
import com.example.util.PdfExportUtil
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Calendar
import java.util.Date

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: OvertimeRepository
    private val preferences: SettingsPreferences = SettingsPreferences(application)
    val records: StateFlow<List<OvertimeRecord>>

    // Live Clock & Date State
    private val _liveClock = MutableStateFlow(OvertimeCalculator.getLiveClockTime())
    val liveClock: StateFlow<String> = _liveClock.asStateFlow()

    private val _displayDate = MutableStateFlow(OvertimeCalculator.getDisplayDate())
    val displayDate: StateFlow<String> = _displayDate.asStateFlow()

    private val _dayOfWeek = MutableStateFlow(OvertimeCalculator.getDayOfWeek())
    val dayOfWeek: StateFlow<String> = _dayOfWeek.asStateFlow()

    private val _todayIsoDate = MutableStateFlow(OvertimeCalculator.getIsoDate())
    val todayIsoDate: StateFlow<String> = _todayIsoDate.asStateFlow()

    // Office Entry Time (Hour, Minute) - default (8, 0) = 08:00 AM
    private val _officeEntryTime = MutableStateFlow(Pair(8, 0))
    val officeEntryTime: StateFlow<Pair<Int, Int>> = _officeEntryTime.asStateFlow()

    // Formatted Office Entry Time string (e.g. "08:00 AM")
    val officeEntryTimeString: StateFlow<String> = MutableStateFlow("08:00 AM")

    // Formatted Standard Shift End Time string (Entry Time + 9 hours, e.g. "05:00 PM")
    val standardShiftEndString: StateFlow<String> = MutableStateFlow("05:00 PM")

    // Live work duration calculation (when not yet punched out)
    private val _liveTotalDuty = MutableStateFlow("00:00")
    val liveTotalDuty: StateFlow<String> = _liveTotalDuty.asStateFlow()

    private val _liveOvertime = MutableStateFlow("00:00")
    val liveOvertime: StateFlow<String> = _liveOvertime.asStateFlow()

    // Status / notification message
    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    init {
        val db = AppDatabase.getDatabase(application)
        repository = OvertimeRepository(db.overtimeRecordDao(), preferences)

        records = repository.allRecords
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        val savedTime = repository.getOfficeEntryTime()
        _officeEntryTime.value = savedTime
        updateEntryTimeStrings(savedTime.first, savedTime.second)

        // Start live 1-second ticker loop
        startLiveTicker()
    }

    private fun updateEntryTimeStrings(hour: Int, minute: Int) {
        (officeEntryTimeString as MutableStateFlow).value = OvertimeCalculator.formatTime(hour, minute)
        val endHour = (hour + OvertimeCalculator.SHIFT_DURATION_HOURS) % 24
        (standardShiftEndString as MutableStateFlow).value = OvertimeCalculator.formatTime(endHour, minute)
    }

    /**
     * Holds today's record if one was already punched today.
     */
    val todayRecord: StateFlow<OvertimeRecord?> = combine(records, _todayIsoDate) { list, todayIso ->
        list.find { it.date == todayIso }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    /**
     * Determines whether the "Punch Out" button is locked for today.
     * Checks both the Room database record for today and SharedPreferences restart protection.
     */
    val isPunchedToday: StateFlow<Boolean> = combine(todayRecord, _todayIsoDate) { record, todayIso ->
        val lastPunchDatePref = preferences.lastPunchDate
        (record != null) || (lastPunchDatePref == todayIso)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    private fun startLiveTicker() {
        viewModelScope.launch {
            while (isActive) {
                val now = Date()
                _liveClock.value = OvertimeCalculator.getLiveClockTime(now)
                _displayDate.value = OvertimeCalculator.getDisplayDate(now)
                _dayOfWeek.value = OvertimeCalculator.getDayOfWeek(now)
                _todayIsoDate.value = OvertimeCalculator.getIsoDate(now)

                // Update live duty calculation aligned with current timestamp
                val entry = _officeEntryTime.value
                val result = OvertimeCalculator.calculateDutyAndOvertime(
                    entryHour = entry.first,
                    entryMinute = entry.second,
                    punchOutDate = now
                )

                _liveTotalDuty.value = result.totalDutyFormatted
                _liveOvertime.value = result.overtimeFormatted

                delay(1000)
            }
        }
    }

    /**
     * Executes punch out for today:
     * 1. Synchronously executes calculateDutyAndOvertime() with exact date alignment BEFORE inserting.
     * 2. Immediately locks restart protection in SharedPreferences.
     * 3. Inserts the record into Room database.
     */
    fun punchOut() {
        val now = Date()
        val entry = _officeEntryTime.value

        // 1. Calculate duty and overtime SYNCHRONOUSLY BEFORE inserting
        val calc = OvertimeCalculator.calculateDutyAndOvertime(
            entryHour = entry.first,
            entryMinute = entry.second,
            punchOutDate = now
        )

        val punchOutCal = Calendar.getInstance().apply { time = now }
        val currentHour = punchOutCal.get(Calendar.HOUR_OF_DAY)
        val currentMinute = punchOutCal.get(Calendar.MINUTE)

        val isoDate = OvertimeCalculator.getIsoDate(now)

        val record = OvertimeRecord(
            date = isoDate,
            displayDate = OvertimeCalculator.getDisplayDate(now),
            dayOfWeek = OvertimeCalculator.getDayOfWeek(now),
            punchInTime = OvertimeCalculator.formatTime(entry.first, entry.second),
            punchOutTime = OvertimeCalculator.formatTime(currentHour, currentMinute),
            punchInMinuteOfDay = calc.punchInMinuteOfDay,
            punchOutMinuteOfDay = calc.punchOutMinuteOfDay,
            totalDutyMinutes = calc.totalDutyMinutes,
            totalDutyFormatted = calc.totalDutyFormatted,
            overtimeMinutes = calc.overtimeMinutes,
            overtimeFormatted = calc.overtimeFormatted,
            timestamp = now.time
        )

        // 2. Synchronously persist lock in SharedPreferences for restart protection
        preferences.lastPunchDate = isoDate

        // 3. Save into Room database
        viewModelScope.launch {
            repository.savePunchRecord(record)
            _userMessage.value = "Punched out at ${record.punchOutTime} | Duty: ${record.totalDutyFormatted} | OT: ${record.overtimeFormatted}"
        }
    }

    /**
     * Updates default Office Entry Time in Settings.
     */
    fun updateOfficeEntryTime(hour: Int, minute: Int) {
        repository.setOfficeEntryTime(hour, minute)
        _officeEntryTime.value = Pair(hour, minute)
        updateEntryTimeStrings(hour, minute)
        _userMessage.value = "Office Entry Time updated to ${OvertimeCalculator.formatTime(hour, minute)}"
    }

    /**
     * Resets Office Entry Time to 08:00 AM.
     */
    fun resetOfficeEntryTimeToDefault() {
        repository.resetOfficeEntryTime()
        _officeEntryTime.value = Pair(8, 0)
        updateEntryTimeStrings(8, 0)
        _userMessage.value = "Office Entry Time reset to 08:00 AM"
    }

    /**
     * Deletes a record from history. If today's record is deleted, unlocks today's punch.
     */
    fun deleteRecord(record: OvertimeRecord) {
        viewModelScope.launch {
            repository.deleteRecord(record)
            if (record.date == _todayIsoDate.value) {
                // Unlock restart protection so user can re-test
                preferences.lastPunchDate = null
            }
            _userMessage.value = "Record deleted"
        }
    }

    /**
     * Clears all records.
     */
    fun clearAllRecords() {
        viewModelScope.launch {
            repository.clearAllRecords()
            preferences.lastPunchDate = null
            _userMessage.value = "All records cleared"
        }
    }

    fun clearUserMessage() {
        _userMessage.value = null
    }

    /**
     * Exports and opens system Share sheet with generated PDF.
     */
    fun exportAndSharePdf(context: Context) {
        val currentRecords = records.value
        val pdfFile = PdfExportUtil.generatePdfReport(context, currentRecords)
        if (pdfFile != null) {
            PdfExportUtil.sharePdf(context, pdfFile)
        } else {
            _userMessage.value = "Failed to create PDF report"
        }
    }

    /**
     * Exports and prints PDF using Android PrintManager.
     */
    fun exportAndPrintPdf(context: Context) {
        val currentRecords = records.value
        val pdfFile = PdfExportUtil.generatePdfReport(context, currentRecords)
        if (pdfFile != null) {
            PdfExportUtil.printPdf(context, pdfFile)
        } else {
            _userMessage.value = "Failed to create PDF report"
        }
    }
}
