package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.OvertimeRecord
import com.example.ui.MainViewModel
import com.example.ui.theme.BentoActivePill
import com.example.ui.theme.BentoBorder
import com.example.ui.theme.BentoCanvas
import com.example.ui.theme.BentoOnSurface
import com.example.ui.theme.BentoOnSurfaceVariant
import com.example.ui.theme.BentoOvertimeBg
import com.example.ui.theme.BentoOvertimeBorder
import com.example.ui.theme.BentoOvertimeText
import com.example.ui.theme.BentoPrimaryPurple
import com.example.ui.theme.BentoSurfaceCard
import com.example.util.OvertimeCalculator

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context: Context = LocalContext.current
    val records by viewModel.records.collectAsStateWithLifecycle()
    val userMessage by viewModel.userMessage.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    var showExportDialog by remember { mutableStateOf(false) }
    var recordToDelete by remember { mutableStateOf<OvertimeRecord?>(null) }
    var showClearAllDialog by remember { mutableStateOf(false) }

    LaunchedEffect(userMessage) {
        userMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearUserMessage()
        }
    }

    // Export/Print Dialog
    if (showExportDialog) {
        AlertDialog(
            onDismissRequest = { showExportDialog = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.PictureAsPdf,
                    contentDescription = null,
                    tint = BentoPrimaryPurple,
                    modifier = Modifier.size(32.dp)
                )
            },
            title = {
                Text(
                    text = "Export & Print History",
                    fontWeight = FontWeight.Bold,
                    color = BentoOnSurface
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        "Export your attendance and overtime table (${records.size} records) in clean PDF format:",
                        color = BentoOnSurfaceVariant
                    )

                    Button(
                        onClick = {
                            showExportDialog = false
                            viewModel.exportAndPrintPdf(context)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("print_pdf_dialog_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = BentoPrimaryPurple),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Print, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Print PDF (Native Printer / Save)")
                    }

                    OutlinedButton(
                        onClick = {
                            showExportDialog = false
                            viewModel.exportAndSharePdf(context)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("share_pdf_dialog_button"),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Share PDF Report File")
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showExportDialog = false }) {
                    Text("Close", color = BentoOnSurfaceVariant)
                }
            }
        )
    }

    // Delete Single Record Confirmation Dialog
    recordToDelete?.let { record ->
        AlertDialog(
            onDismissRequest = { recordToDelete = null },
            title = { Text("Delete Entry", color = BentoOnSurface) },
            text = {
                Text(
                    "Delete record for ${record.displayDate} (${record.punchInTime} - ${record.punchOutTime})?",
                    color = BentoOnSurfaceVariant
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteRecord(record)
                        recordToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { recordToDelete = null }) {
                    Text("Cancel", color = BentoOnSurfaceVariant)
                }
            }
        )
    }

    // Clear All Confirmation Dialog
    if (showClearAllDialog) {
        AlertDialog(
            onDismissRequest = { showClearAllDialog = false },
            title = { Text("Clear All History", color = BentoOnSurface) },
            text = {
                Text(
                    "Are you sure you want to permanently clear all recorded history? This cannot be undone.",
                    color = BentoOnSurfaceVariant
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showClearAllDialog = false
                        viewModel.clearAllRecords()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Clear All")
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearAllDialog = false }) {
                    Text("Cancel", color = BentoOnSurfaceVariant)
                }
            }
        )
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(BentoCanvas),
        containerColor = BentoCanvas,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "History & Records",
                        fontWeight = FontWeight.SemiBold,
                        color = BentoOnSurface,
                        letterSpacing = (-0.5).sp
                    )
                },
                navigationIcon = {
                    Surface(
                        shape = CircleShape,
                        color = BentoSurfaceCard,
                        modifier = Modifier
                            .padding(start = 12.dp)
                            .size(40.dp)
                            .testTag("history_back_button")
                    ) {
                        IconButton(onClick = onNavigateBack) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = BentoOnSurface,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                },
                actions = {
                    if (records.isNotEmpty()) {
                        Surface(
                            shape = CircleShape,
                            color = BentoSurfaceCard,
                            modifier = Modifier
                                .size(40.dp)
                                .testTag("export_pdf_button")
                        ) {
                            IconButton(onClick = { showExportDialog = true }) {
                                Icon(
                                    imageVector = Icons.Default.Print,
                                    contentDescription = "Export or Print PDF",
                                    tint = BentoPrimaryPurple,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            shape = CircleShape,
                            color = BentoSurfaceCard,
                            modifier = Modifier
                                .padding(end = 12.dp)
                                .size(40.dp)
                                .testTag("clear_all_button")
                        ) {
                            IconButton(onClick = { showClearAllDialog = true }) {
                                Icon(
                                    imageVector = Icons.Default.DeleteSweep,
                                    contentDescription = "Clear History",
                                    tint = BentoOnSurfaceVariant,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = BentoCanvas
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Header Stats Bento Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = BentoSurfaceCard),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    val totalDutyMinutes = records.sumOf { it.totalDutyMinutes }
                    val totalOvertimeMinutes = records.sumOf { it.overtimeMinutes }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Total Entries: ${records.size}",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = BentoOnSurface
                            )
                            Text(
                                text = "Total Duty: ${OvertimeCalculator.formatDuration(totalDutyMinutes)}",
                                fontSize = 13.sp,
                                color = BentoOnSurfaceVariant
                            )
                            Text(
                                text = "Total Overtime: ${OvertimeCalculator.formatDuration(totalOvertimeMinutes)}",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = BentoOvertimeText
                            )
                        }

                        Button(
                            onClick = { showExportDialog = true },
                            enabled = records.isNotEmpty(),
                            colors = ButtonDefaults.buttonColors(containerColor = BentoPrimaryPurple),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.testTag("export_print_pdf_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.PictureAsPdf,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Export / Print", fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            if (records.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = BentoActivePill,
                            modifier = Modifier.size(64.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.TableChart,
                                    contentDescription = null,
                                    tint = BentoPrimaryPurple,
                                    modifier = Modifier.size(32.dp)
                                )
                            }
                        }
                        Text(
                            text = "No History Records Yet",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = BentoOnSurface
                        )
                        Text(
                            text = "When you punch out on the Home screen, your work hours and overtime will be saved here in a clean table.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = BentoOnSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                val horizontalScrollState = rememberScrollState()

                // Fixed column widths
                val colDateWidth = 110.dp
                val colPunchInWidth = 90.dp
                val colPunchOutWidth = 90.dp
                val colDutyWidth = 95.dp
                val colOvertimeWidth = 95.dp
                val colActionWidth = 46.dp
                val totalTableWidth = colDateWidth + colPunchInWidth + colPunchOutWidth + colDutyWidth + colOvertimeWidth + colActionWidth

                Card(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BentoBorder),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .horizontalScroll(horizontalScrollState)
                            .width(totalTableWidth)
                    ) {
                        // Table Header Row
                        Surface(
                            color = BentoPrimaryPurple,
                            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 12.dp, horizontal = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                TableHeaderCell(text = "Date", width = colDateWidth)
                                TableHeaderCell(text = "Punch in", width = colPunchInWidth)
                                TableHeaderCell(text = "Punch out", width = colPunchOutWidth)
                                TableHeaderCell(text = "Total deuty", width = colDutyWidth)
                                TableHeaderCell(text = "Over time", width = colOvertimeWidth)
                                TableHeaderCell(text = "", width = colActionWidth)
                            }
                        }

                        // Table Body Rows
                        LazyColumn(modifier = Modifier.fillMaxSize()) {
                            itemsIndexed(records, key = { _, item -> item.id }) { index, record ->
                                val isAlternate = index % 2 == 1
                                val rowBgColor = if (isAlternate) BentoSurfaceCard.copy(alpha = 0.5f) else Color.White

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(rowBgColor)
                                        .padding(vertical = 10.dp, horizontal = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // 1. Date column
                                    Column(modifier = Modifier.width(colDateWidth)) {
                                        Text(
                                            text = record.displayDate,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = BentoOnSurface
                                        )
                                        Text(
                                            text = record.dayOfWeek,
                                            fontSize = 11.sp,
                                            color = BentoOnSurfaceVariant
                                        )
                                    }

                                    // 2. Punch In column
                                    TableCell(
                                        text = record.punchInTime,
                                        width = colPunchInWidth,
                                        fontWeight = FontWeight.Medium
                                    )

                                    // 3. Punch Out column
                                    TableCell(
                                        text = record.punchOutTime,
                                        width = colPunchOutWidth,
                                        fontWeight = FontWeight.Medium
                                    )

                                    // 4. Total Duty column
                                    TableCell(
                                        text = record.totalDutyFormatted,
                                        width = colDutyWidth,
                                        fontWeight = FontWeight.SemiBold
                                    )

                                    // 5. Over Time column
                                    Box(
                                        modifier = Modifier.width(colOvertimeWidth),
                                        contentAlignment = Alignment.CenterStart
                                    ) {
                                        if (record.overtimeMinutes > 0) {
                                            Surface(
                                                shape = RoundedCornerShape(8.dp),
                                                color = BentoOvertimeBg,
                                                border = androidx.compose.foundation.BorderStroke(1.dp, BentoOvertimeBorder)
                                            ) {
                                                Text(
                                                    text = record.overtimeFormatted,
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = BentoOvertimeText,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                        } else {
                                            Text(
                                                text = "0h 00m",
                                                fontSize = 13.sp,
                                                color = BentoOnSurfaceVariant
                                            )
                                        }
                                    }

                                    // Delete Action
                                    Box(
                                        modifier = Modifier.width(colActionWidth),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        IconButton(
                                            onClick = { recordToDelete = record },
                                            modifier = Modifier
                                                .size(32.dp)
                                                .testTag("delete_record_${record.id}")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Delete,
                                                contentDescription = "Delete record",
                                                tint = BentoOnSurfaceVariant.copy(alpha = 0.6f),
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }

                                HorizontalDivider(color = BentoBorder.copy(alpha = 0.5f))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TableHeaderCell(text: String, width: androidx.compose.ui.unit.Dp) {
    Text(
        text = text,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        color = Color.White,
        modifier = Modifier.width(width)
    )
}

@Composable
private fun TableCell(
    text: String,
    width: androidx.compose.ui.unit.Dp,
    fontWeight: FontWeight = FontWeight.Normal,
    color: Color = BentoOnSurface
) {
    Text(
        text = text,
        fontSize = 13.sp,
        fontWeight = fontWeight,
        color = color,
        modifier = Modifier.width(width)
    )
}
