package com.example.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object OvertimeCalculator {

    // Lunch window: 01:00 PM (13:00) to 02:00 PM (14:00)
    const val LUNCH_START_HOUR = 13
    const val LUNCH_START_MINUTE = 13 * 60 // 780
    const val LUNCH_END_HOUR = 14
    const val LUNCH_END_MINUTE = 14 * 60   // 840

    // Mandatory shift duration: 9 hours
    const val SHIFT_DURATION_HOURS = 9
    const val SHIFT_DURATION_MINUTES = 9 * 60 // 540

    data class CalculationResult(
        val punchInMinuteOfDay: Int,
        val punchOutMinuteOfDay: Int,
        val totalSpanMinutes: Int,
        val lunchDeductedMinutes: Int,
        val totalDutyMinutes: Int,
        val overtimeMinutes: Int,
        val totalDutyFormatted: String,  // Formatted as "hh:mm"
        val overtimeFormatted: String,   // Formatted strictly as "00:00", "01:00", etc.
        val standardEndFormatted: String // e.g. "05:00 PM"
    )

    /**
     * Aligns an entry time (hour and minute) to the exact calendar year, month,
     * and day-of-month of the reference date (e.g. the Punch Out timestamp)
     * to guarantee accurate millisecond calculation and avoid 0 ms duration bugs.
     */
    fun alignEntryTimeToDate(
        entryHour: Int,
        entryMinute: Int,
        referenceDate: Date = Date()
    ): Calendar {
        return Calendar.getInstance().apply {
            time = referenceDate
            set(Calendar.HOUR_OF_DAY, entryHour)
            set(Calendar.MINUTE, entryMinute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
    }

    /**
     * Parses an Entry Time string (e.g. "08:00 AM", "09:00 AM") into (hour, minute)
     * fallback to (8, 0) if parsing fails.
     */
    fun parseEntryTimeString(entryTimeString: String): Pair<Int, Int> {
        return try {
            val sdf = SimpleDateFormat("hh:mm a", Locale.US)
            val parsed = sdf.parse(entryTimeString.trim())
            if (parsed != null) {
                val cal = Calendar.getInstance().apply { time = parsed }
                Pair(cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE))
            } else {
                Pair(8, 0)
            }
        } catch (e: Exception) {
            Pair(8, 0)
        }
    }

    /**
     * Calculates duty hours and overtime according to the updated business logic:
     * 1. Dynamic Shift End Time: Standard End Time = Office Entry Time + 9 hours.
     * 2. Lunch Deduction: Lunch is 01:00 PM (13:00) to 02:00 PM (14:00).
     *    - If Punch Out > 02:00 PM and Punch In < 01:00 PM: deduct exactly 1 hour (60 minutes).
     *    - If Punch Out is between 01:00 PM and 02:00 PM: deduct exact difference (Punch Out - 01:00 PM).
     *    - Otherwise deduct proportional overlap if worked during lunch.
     * 3. Total Duty = (Punch Out - Punch In) - Lunch Duration. Format as "hh:mm".
     * 4. Strict Full-Hour Overtime:
     *    - Overtime starts ONLY after Standard End Time (Entry Time + 9 hours).
     *    - Overtime must NEVER contain minutes; strictly increments in full hours only
     *      using floor integer division: otMillis / (1000 * 60 * 60).
     *    - Any extra minutes under 60 do not count.
     *    - Formatted strictly as "00:00", "01:00", "02:00", etc.
     */
    fun calculateDutyAndOvertime(
        entryHour: Int,
        entryMinute: Int,
        punchOutDate: Date = Date()
    ): CalculationResult {
        val punchOutCal = Calendar.getInstance().apply { time = punchOutDate }
        val exitHour = punchOutCal.get(Calendar.HOUR_OF_DAY)
        val exitMinute = punchOutCal.get(Calendar.MINUTE)

        // Align entry time to the exact date of punch out
        val punchInCal = alignEntryTimeToDate(entryHour, entryMinute, punchOutDate)

        val inMillis = punchInCal.timeInMillis
        val outMillis = punchOutCal.timeInMillis

        val inMinuteOfDay = entryHour * 60 + entryMinute
        val outMinuteOfDay = exitHour * 60 + exitMinute

        // Total raw span in minutes
        val totalSpanMillis = (outMillis - inMillis).coerceAtLeast(0L)
        val totalSpanMinutes = (totalSpanMillis / (1000L * 60)).toInt()

        // Lunch break deduction (01:00 PM = 13:00 = 780 min to 02:00 PM = 14:00 = 840 min)
        val lunchDeductedMinutes = when {
            // Punch Out > 02:00 PM and Punch In < 01:00 PM -> deduct exactly 60 minutes
            inMinuteOfDay < LUNCH_START_MINUTE && outMinuteOfDay > LUNCH_END_MINUTE -> 60

            // Punch Out is between 01:00 PM and 02:00 PM -> deduct (Punch Out - 01:00 PM)
            inMinuteOfDay < LUNCH_START_MINUTE && outMinuteOfDay in LUNCH_START_MINUTE..LUNCH_END_MINUTE -> {
                (outMinuteOfDay - LUNCH_START_MINUTE).coerceAtLeast(0)
            }

            // Punch In was during lunch and Punch Out after lunch
            inMinuteOfDay in LUNCH_START_MINUTE..LUNCH_END_MINUTE && outMinuteOfDay > LUNCH_END_MINUTE -> {
                (LUNCH_END_MINUTE - inMinuteOfDay).coerceAtLeast(0)
            }

            // Both Punch In and Punch Out occurred within lunch hour
            inMinuteOfDay in LUNCH_START_MINUTE..LUNCH_END_MINUTE && outMinuteOfDay in LUNCH_START_MINUTE..LUNCH_END_MINUTE -> {
                (outMinuteOfDay - inMinuteOfDay).coerceAtLeast(0)
            }

            else -> 0
        }

        // Total Duty = (Punch Out - Punch In) - Lunch Duration. Format as "hh:mm"
        val totalDutyMinutes = (totalSpanMinutes - lunchDeductedMinutes).coerceAtLeast(0)
        val dutyHours = totalDutyMinutes / 60
        val dutyMins = totalDutyMinutes % 60
        val totalDutyFormatted = String.format(Locale.US, "%02d:%02d", dutyHours, dutyMins)

        // Standard End Time = Office Entry Time + 9 hours
        val standardEndMillis = inMillis + (SHIFT_DURATION_HOURS.toLong() * 60 * 60 * 1000)
        val standardEndCal = Calendar.getInstance().apply { timeInMillis = standardEndMillis }
        val standardEndFormatted = formatTime(
            standardEndCal.get(Calendar.HOUR_OF_DAY),
            standardEndCal.get(Calendar.MINUTE)
        )

        // Strict Full-Hour Overtime Logic:
        // Overtime starts ONLY after Standard End Time (Entry Time + 9 hours).
        // Overtime strictly increments in full hours only (floor integer division):
        // otMillis / (1000 * 60 * 60). Any extra minutes under 60 do not count.
        val otMillis = (outMillis - standardEndMillis).coerceAtLeast(0L)
        val fullOvertimeHours = (otMillis / (1000L * 60 * 60)).toInt() // floor integer division
        val overtimeMinutes = fullOvertimeHours * 60
        val overtimeFormatted = String.format(Locale.US, "%02d:00", fullOvertimeHours)

        return CalculationResult(
            punchInMinuteOfDay = inMinuteOfDay,
            punchOutMinuteOfDay = outMinuteOfDay,
            totalSpanMinutes = totalSpanMinutes,
            lunchDeductedMinutes = lunchDeductedMinutes,
            totalDutyMinutes = totalDutyMinutes,
            overtimeMinutes = overtimeMinutes,
            totalDutyFormatted = totalDutyFormatted,
            overtimeFormatted = overtimeFormatted,
            standardEndFormatted = standardEndFormatted
        )
    }

    /**
     * Overload for testing or direct hour/minute inputs on the same calendar day.
     */
    fun calculateDutyAndOvertime(
        entryHour: Int,
        entryMinute: Int,
        exitHour: Int,
        exitMinute: Int
    ): CalculationResult {
        val now = Date()
        val punchOutCal = Calendar.getInstance().apply {
            time = now
            set(Calendar.HOUR_OF_DAY, exitHour)
            set(Calendar.MINUTE, exitMinute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        return calculateDutyAndOvertime(entryHour, entryMinute, punchOutCal.time)
    }

    /**
     * Formats hour and minute into "hh:mm a" (e.g. "08:00 AM", "05:00 PM")
     */
    fun formatTime(hour: Int, minute: Int): String {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
        }
        val sdf = SimpleDateFormat("hh:mm a", Locale.US)
        return sdf.format(cal.time)
    }

    /**
     * Formats duration in minutes to "hh:mm"
     */
    fun formatDuration(totalMinutes: Int): String {
        return formatDurationHHMM(totalMinutes)
    }

    /**
     * Formats duration in minutes to "hh:mm"
     */
    fun formatDurationHHMM(totalMinutes: Int): String {
        val hours = (totalMinutes / 60).coerceAtLeast(0)
        val minutes = (totalMinutes % 60).coerceAtLeast(0)
        return String.format(Locale.US, "%02d:%02d", hours, minutes)
    }

    /**
     * Formats current date to ISO date string "YYYY-MM-DD"
     */
    fun getIsoDate(date: Date = Date()): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        return sdf.format(date)
    }

    /**
     * Formats current date to readable display date "MMM dd, yyyy"
     */
    fun getDisplayDate(date: Date = Date()): String {
        val sdf = SimpleDateFormat("MMM dd, yyyy", Locale.US)
        return sdf.format(date)
    }

    /**
     * Gets day of week name (e.g. "Monday")
     */
    fun getDayOfWeek(date: Date = Date()): String {
        val sdf = SimpleDateFormat("EEEE", Locale.US)
        return sdf.format(date)
    }

    /**
     * Formats current time for live clock "hh:mm:ss a"
     */
    fun getLiveClockTime(date: Date = Date()): String {
        val sdf = SimpleDateFormat("hh:mm:ss a", Locale.US)
        return sdf.format(date)
    }
}
