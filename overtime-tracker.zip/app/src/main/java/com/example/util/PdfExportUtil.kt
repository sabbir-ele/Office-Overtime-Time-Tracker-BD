package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.local.OvertimeRecord
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PdfExportUtil {

    private const val PAGE_WIDTH = 595 // A4 width in points (72 dpi)
    private const val PAGE_HEIGHT = 842 // A4 height in points (72 dpi)
    private const val MARGIN = 36f

    /**
     * Generates a PDF file from the list of Overtime records.
     * Returns the generated File object or null on error.
     */
    fun generatePdfReport(context: Context, records: List<OvertimeRecord>): File? {
        val document = PdfDocument()

        val titlePaint = Paint().apply {
            color = Color.parseColor("#1E3A8A")
            textSize = 20f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val subtitlePaint = Paint().apply {
            color = Color.parseColor("#475569")
            textSize = 10f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            isAntiAlias = true
        }

        val headerBoxPaint = Paint().apply {
            color = Color.parseColor("#1E3A8A")
            style = Paint.Style.FILL
            isAntiAlias = true
        }

        val headerTextPaint = Paint().apply {
            color = Color.WHITE
            textSize = 10f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val rowTextPaint = Paint().apply {
            color = Color.parseColor("#0F172A")
            textSize = 9.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            isAntiAlias = true
        }

        val overtimeHighlightPaint = Paint().apply {
            color = Color.parseColor("#D97706")
            textSize = 9.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val alternateRowPaint = Paint().apply {
            color = Color.parseColor("#F8FAFC")
            style = Paint.Style.FILL
        }

        val whiteRowPaint = Paint().apply {
            color = Color.WHITE
            style = Paint.Style.FILL
        }

        val linePaint = Paint().apply {
            color = Color.parseColor("#CBD5E1")
            strokeWidth = 0.75f
            style = Paint.Style.STROKE
        }

        val summaryCardPaint = Paint().apply {
            color = Color.parseColor("#EFF6FF")
            style = Paint.Style.FILL
        }

        val summaryBorderPaint = Paint().apply {
            color = Color.parseColor("#BFDBFE")
            strokeWidth = 1f
            style = Paint.Style.STROKE
        }

        // Table column widths
        val tableWidth = PAGE_WIDTH - (MARGIN * 2)
        val colDateWidth = tableWidth * 0.24f
        val colPunchInWidth = tableWidth * 0.19f
        val colPunchOutWidth = tableWidth * 0.19f
        val colDutyWidth = tableWidth * 0.19f
        val colOvertimeWidth = tableWidth * 0.19f

        val rowHeight = 24f
        val maxRowsPerPage = 22

        val totalPages = if (records.isEmpty()) 1 else ((records.size - 1) / maxRowsPerPage) + 1

        val totalDutyMinutes = records.sumOf { it.totalDutyMinutes }
        val totalOvertimeMinutes = records.sumOf { it.overtimeMinutes }

        val sdf = SimpleDateFormat("MMM dd, yyyy - hh:mm a", Locale.getDefault())
        val generatedDateStr = sdf.format(Date())

        var recordIndex = 0

        for (pageNumber in 1..totalPages) {
            val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create()
            val page = document.startPage(pageInfo)
            val canvas: Canvas = page.canvas

            var currentY = MARGIN

            // Title & Subtitle (Header shown on all pages)
            canvas.drawText("OVERTIME TRACKER", MARGIN, currentY + 18f, titlePaint)
            currentY += 24f
            canvas.drawText("Official Duty & Overtime Attendance Report", MARGIN, currentY + 10f, subtitlePaint)
            currentY += 16f
            canvas.drawText("Generated: $generatedDateStr  |  Total Entries: ${records.size}", MARGIN, currentY + 8f, subtitlePaint)
            currentY += 16f

            // On First Page: Draw Summary Box
            if (pageNumber == 1) {
                val summaryRect = RectF(MARGIN, currentY, MARGIN + tableWidth, currentY + 36f)
                canvas.drawRoundRect(summaryRect, 6f, 6f, summaryCardPaint)
                canvas.drawRoundRect(summaryRect, 6f, 6f, summaryBorderPaint)

                val summaryTextPaint = Paint().apply {
                    color = Color.parseColor("#1E3A8A")
                    textSize = 10f
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                    isAntiAlias = true
                }
                val summaryValuePaint = Paint().apply {
                    color = Color.parseColor("#0F172A")
                    textSize = 9.5f
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                    isAntiAlias = true
                }

                val stat1 = "Total Records: ${records.size}"
                val stat2 = "Total Duty: ${OvertimeCalculator.formatDuration(totalDutyMinutes)}"
                val stat3 = "Total Overtime: ${OvertimeCalculator.formatDuration(totalOvertimeMinutes)}"

                val sectionWidth = tableWidth / 3f
                canvas.drawText(stat1, MARGIN + 12f, currentY + 22f, summaryValuePaint)
                canvas.drawText(stat2, MARGIN + sectionWidth + 12f, currentY + 22f, summaryValuePaint)
                canvas.drawText(stat3, MARGIN + (sectionWidth * 2) + 12f, currentY + 22f, summaryTextPaint)

                currentY += 46f
            } else {
                currentY += 10f
            }

            // Table Header
            val headerRect = RectF(MARGIN, currentY, MARGIN + tableWidth, currentY + rowHeight)
            canvas.drawRoundRect(headerRect, 4f, 4f, headerBoxPaint)

            var colX = MARGIN + 8f
            canvas.drawText("Date", colX, currentY + 16f, headerTextPaint)
            colX += colDateWidth
            canvas.drawText("Punch in", colX, currentY + 16f, headerTextPaint)
            colX += colPunchInWidth
            canvas.drawText("Punch out", colX, currentY + 16f, headerTextPaint)
            colX += colPunchOutWidth
            canvas.drawText("Total deuty", colX, currentY + 16f, headerTextPaint)
            colX += colDutyWidth
            canvas.drawText("Over time", colX, currentY + 16f, headerTextPaint)

            currentY += rowHeight

            if (records.isEmpty()) {
                canvas.drawText("No records recorded yet.", MARGIN + 16f, currentY + 25f, rowTextPaint)
            } else {
                var rowsThisPage = 0
                while (recordIndex < records.size && rowsThisPage < maxRowsPerPage) {
                    val record = records[recordIndex]
                    val isAlternate = rowsThisPage % 2 == 1
                    val bgPaint = if (isAlternate) alternateRowPaint else whiteRowPaint

                    canvas.drawRect(MARGIN, currentY, MARGIN + tableWidth, currentY + rowHeight, bgPaint)
                    canvas.drawLine(MARGIN, currentY + rowHeight, MARGIN + tableWidth, currentY + rowHeight, linePaint)

                    var cellX = MARGIN + 8f
                    canvas.drawText(record.displayDate, cellX, currentY + 16f, rowTextPaint)
                    cellX += colDateWidth
                    canvas.drawText(record.punchInTime, cellX, currentY + 16f, rowTextPaint)
                    cellX += colPunchInWidth
                    canvas.drawText(record.punchOutTime, cellX, currentY + 16f, rowTextPaint)
                    cellX += colPunchOutWidth
                    canvas.drawText(record.totalDutyFormatted, cellX, currentY + 16f, rowTextPaint)
                    cellX += colDutyWidth

                    val otPaint = if (record.overtimeMinutes > 0) overtimeHighlightPaint else rowTextPaint
                    canvas.drawText(record.overtimeFormatted, cellX, currentY + 16f, otPaint)

                    currentY += rowHeight
                    rowsThisPage++
                    recordIndex++
                }

                // Table outer border
                canvas.drawRect(MARGIN, currentY - (rowsThisPage * rowHeight), MARGIN + tableWidth, currentY, linePaint)
            }

            // Page Number in footer
            val footerPaint = Paint().apply {
                color = Color.parseColor("#94A3B8")
                textSize = 9f
                isAntiAlias = true
            }
            val pageText = "Page $pageNumber of $totalPages  •  Overtime Tracker"
            canvas.drawText(pageText, MARGIN, PAGE_HEIGHT - 20f, footerPaint)

            document.finishPage(page)
        }

        return try {
            val pdfDir = File(context.cacheDir, "pdf_reports")
            if (!pdfDir.exists()) {
                pdfDir.mkdirs()
            }
            val pdfFile = File(pdfDir, "Overtime_Report_${System.currentTimeMillis()}.pdf")
            val outputStream = FileOutputStream(pdfFile)
            document.writeTo(outputStream)
            outputStream.close()
            document.close()
            pdfFile
        } catch (e: Exception) {
            e.printStackTrace()
            document.close()
            null
        }
    }

    /**
     * Shares the generated PDF file using the Android system share sheet.
     */
    fun sharePdf(context: Context, pdfFile: File) {
        try {
            val authority = "${context.packageName}.fileprovider"
            val contentUri = FileProvider.getUriForFile(context, authority, pdfFile)

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, contentUri)
                putExtra(Intent.EXTRA_SUBJECT, "Overtime Tracker - Attendance Report")
                putExtra(Intent.EXTRA_TEXT, "Attached is the Overtime and Duty Attendance Report from Overtime Tracker.")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            val chooser = Intent.createChooser(shareIntent, "Share Overtime Report")
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "Failed to share PDF: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Native Android print dialog using PrintManager.
     */
    fun printPdf(context: Context, pdfFile: File) {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager
        if (printManager == null) {
            Toast.makeText(context, "Print service not available on this device", Toast.LENGTH_SHORT).show()
            return
        }

        val printAdapter = object : PrintDocumentAdapter() {
            override fun onLayout(
                oldAttributes: PrintAttributes?,
                newAttributes: PrintAttributes?,
                cancellationSignal: CancellationSignal?,
                callback: LayoutResultCallback?,
                extras: Bundle?
            ) {
                if (cancellationSignal?.isCanceled == true) {
                    callback?.onLayoutCancelled()
                    return
                }

                val pdi = PrintDocumentInfo.Builder("Overtime_Attendance_Report.pdf")
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .build()

                callback?.onLayoutFinished(pdi, true)
            }

            override fun onWrite(
                pages: Array<out PageRange>?,
                destination: ParcelFileDescriptor?,
                cancellationSignal: CancellationSignal?,
                callback: WriteResultCallback?
            ) {
                var input: FileInputStream? = null
                var output: FileOutputStream? = null

                try {
                    input = FileInputStream(pdfFile)
                    output = FileOutputStream(destination?.fileDescriptor)

                    val buf = ByteArray(1024)
                    var bytesRead: Int
                    while (input.read(buf).also { bytesRead = it } > 0) {
                        if (cancellationSignal?.isCanceled == true) {
                            callback?.onWriteCancelled()
                            return
                        }
                        output.write(buf, 0, bytesRead)
                    }

                    callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                } catch (e: Exception) {
                    callback?.onWriteFailed(e.message)
                } finally {
                    try {
                        input?.close()
                        output?.close()
                    } catch (e: IOException) {
                        e.printStackTrace()
                    }
                }
            }
        }

        val printJobName = "Overtime Report ${System.currentTimeMillis()}"
        val printAttributes = PrintAttributes.Builder()
            .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
            .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
            .build()

        printManager.print(printJobName, printAdapter, printAttributes)
    }
}
