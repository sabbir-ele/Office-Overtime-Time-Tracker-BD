package com.example.data.preferences

import android.content.Context
import android.content.SharedPreferences

class SettingsPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("overtime_settings_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_ENTRY_HOUR = "key_office_entry_hour"
        private const val KEY_ENTRY_MINUTE = "key_office_entry_minute"
        private const val KEY_LAST_PUNCH_DATE = "key_last_punch_date"

        const val DEFAULT_ENTRY_HOUR = 8
        const val DEFAULT_ENTRY_MINUTE = 0
    }

    var officeEntryHour: Int
        get() = prefs.getInt(KEY_ENTRY_HOUR, DEFAULT_ENTRY_HOUR)
        set(value) = prefs.edit().putInt(KEY_ENTRY_HOUR, value).apply()

    var officeEntryMinute: Int
        get() = prefs.getInt(KEY_ENTRY_MINUTE, DEFAULT_ENTRY_MINUTE)
        set(value) = prefs.edit().putInt(KEY_ENTRY_MINUTE, value).apply()

    var lastPunchDate: String?
        get() = prefs.getString(KEY_LAST_PUNCH_DATE, null)
        set(value) = prefs.edit().putString(KEY_LAST_PUNCH_DATE, value).apply()

    fun resetToDefault() {
        prefs.edit()
            .putInt(KEY_ENTRY_HOUR, DEFAULT_ENTRY_HOUR)
            .putInt(KEY_ENTRY_MINUTE, DEFAULT_ENTRY_MINUTE)
            .apply()
    }
}
