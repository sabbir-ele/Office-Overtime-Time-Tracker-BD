package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Entity representing a daily punch record.
 */
@Entity(tableName = "overtime_records")
data class OvertimeRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val date: String,               // ISO format: YYYY-MM-DD for indexing and comparison
    val displayDate: String,        // e.g. "Sep 04, 2026"
    val dayOfWeek: String,          // e.g. "Friday"
    val punchInTime: String,        // e.g. "08:00 AM"
    val punchOutTime: String,       // e.g. "06:30 PM"
    val punchInMinuteOfDay: Int,    // minutes from midnight (e.g. 8 * 60 = 480)
    val punchOutMinuteOfDay: Int,   // minutes from midnight (e.g. 18 * 60 + 30 = 1110)
    val totalDutyMinutes: Int,      // Total duty in minutes after deducting lunch
    val totalDutyFormatted: String, // e.g. "9h 30m"
    val overtimeMinutes: Int,       // Overtime in minutes (worked after 5:00 PM / duty end)
    val overtimeFormatted: String,  // e.g. "1h 30m"
    val timestamp: Long = System.currentTimeMillis()
)
