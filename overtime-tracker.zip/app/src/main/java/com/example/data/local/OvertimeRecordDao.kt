package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface OvertimeRecordDao {
    @Query("SELECT * FROM overtime_records ORDER BY date DESC, id DESC")
    fun getAllRecords(): Flow<List<OvertimeRecord>>

    @Query("SELECT * FROM overtime_records WHERE date = :date LIMIT 1")
    suspend fun getRecordByDate(date: String): OvertimeRecord?

    @Query("SELECT * FROM overtime_records WHERE date = :date LIMIT 1")
    fun getRecordByDateFlow(date: String): Flow<OvertimeRecord?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecord(record: OvertimeRecord): Long

    @Update
    suspend fun updateRecord(record: OvertimeRecord)

    @Delete
    suspend fun deleteRecord(record: OvertimeRecord)

    @Query("DELETE FROM overtime_records WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM overtime_records")
    suspend fun clearAll()
}
