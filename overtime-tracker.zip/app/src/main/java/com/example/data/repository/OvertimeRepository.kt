package com.example.data.repository

import com.example.data.local.OvertimeRecord
import com.example.data.local.OvertimeRecordDao
import com.example.data.preferences.SettingsPreferences
import kotlinx.coroutines.flow.Flow

class OvertimeRepository(
    private val dao: OvertimeRecordDao,
    private val preferences: SettingsPreferences
) {
    val allRecords: Flow<List<OvertimeRecord>> = dao.getAllRecords()

    suspend fun getRecordForDate(date: String): OvertimeRecord? {
        return dao.getRecordByDate(date)
    }

    fun getRecordForDateFlow(date: String): Flow<OvertimeRecord?> {
        return dao.getRecordByDateFlow(date)
    }

    suspend fun savePunchRecord(record: OvertimeRecord): Long {
        val id = dao.insertRecord(record)
        preferences.lastPunchDate = record.date
        return id
    }

    suspend fun deleteRecord(record: OvertimeRecord) {
        dao.deleteRecord(record)
    }

    suspend fun deleteRecordById(id: Long) {
        dao.deleteById(id)
    }

    suspend fun clearAllRecords() {
        dao.clearAll()
        preferences.lastPunchDate = null
    }

    fun getOfficeEntryTime(): Pair<Int, Int> {
        return Pair(preferences.officeEntryHour, preferences.officeEntryMinute)
    }

    fun setOfficeEntryTime(hour: Int, minute: Int) {
        preferences.officeEntryHour = hour
        preferences.officeEntryMinute = minute
    }

    fun resetOfficeEntryTime() {
        preferences.resetToDefault()
    }

    fun getLastPunchDate(): String? {
        return preferences.lastPunchDate
    }
}
